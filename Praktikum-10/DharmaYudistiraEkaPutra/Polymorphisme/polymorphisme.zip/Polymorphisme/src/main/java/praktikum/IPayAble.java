package praktikum;

public interface IPayAble {
    int getPaymentInfo();
}
