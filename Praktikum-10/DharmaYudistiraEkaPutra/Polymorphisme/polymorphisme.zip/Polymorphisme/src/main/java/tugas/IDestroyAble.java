package tugas;

public interface IDestroyAble {
    void destroyed();
}
